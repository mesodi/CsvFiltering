package es.wacoco.csvfiltering;

import es.wacoco.csvfiltering.model.Job;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class JobTest {


}

